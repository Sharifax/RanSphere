global normal_domain_count
global gib_domain_count
import ML
import gib_detect
import multiprocessing

def run_ML():
    result = ML.ML_main()
    return result

def run_gib_detect():
    gib_detect.Gib_Main()

def main():
    p2 = multiprocessing.Process(target=run_gib_detect, daemon=True)
    p2.start()

    result = run_ML()
    if(result):
        p2.kill()
    return result
