import pandas as pd
import numpy as np
import joblib
import time
import ipaddress
import os
import subprocess
import threading
from pandas.errors import EmptyDataError

global counter
global ArrayIndexes

counter = 0
ArrayIndexes = []
running = True


def sniffer():
    command = 'C:/Users/ccsit/AppData/Local/Programs/Python/Python311/Scripts/cicflowmeter.exe -i Ethernet -c C:/Users/ccsit/Documents/RanSphere/RanSphere/NormalTraffic.csv'
    subprocess.run(command, check=True, shell=True, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                   stderr=subprocess.DEVNULL)


def Predict(df1):
    global counter
    # returns Series
    df1 = df1.replace(np.nan, 0)
    # returns DF
    df = pd.DataFrame([df1.rename(None)])
    # convert
    df['int_src_ip'] = df['src_ip'].apply(lambda x: int(ipaddress.IPv4Address(x)))
    df['int_dst_ip'] = df['dst_ip'].apply(lambda x: int(ipaddress.IPv4Address(x)))

    df['src_ip'] = df['src_ip'].astype('str').str.replace(r".", r"", regex=False)
    df["src_ip"] = df["src_ip"].apply(lambda x: int(x))
    df['dst_ip'] = df['dst_ip'].astype('str').str.replace(r".", r"", regex=False)
    df["dst_ip"] = df["dst_ip"].apply(lambda x: int(x))

    df["src_ip"] = df['int_src_ip']
    df["dst_ip"] = df['int_dst_ip']

    counter += 1

    x1 = df[['src_ip', 'dst_ip', 'src_port', 'dst_port', 'protocol', 'flow_duration', 'tot_bwd_pkts', 'fwd_pkt_len_min',
             'bwd_pkt_len_max', 'bwd_pkt_len_min', 'psh_flag_cnt', 'ack_flag_cnt', 'rst_flag_cnt', 'pkt_size_avg']]

    print("*", DT_from_joblib.predict(x1))
    check = DT_from_joblib.predict(x1)

    if(check == 1):
        return "[1]"



DT_from_joblib = joblib.load('C:/Users/ccsit/Documents/RanSphere/RanSphere/my_model_DT.pkl')


def check_file_modification(filename):
    global running
    while running:
        if os.path.exists(filename):
            try:
               
                try:
                    df = pd.read_csv(filename)
                except EmptyDataError as m:
                    continue

                # Process each row of the DataFrame
                for index, row in df.iterrows():
                    if index in ArrayIndexes:
                        continue
                    else:
                        predection4 = Predict(row)
                        ArrayIndexes.append(index)
                        if (predection4):
                            return predection4
            except Exception as e:
                print(f"Error occurred while predicting: {e}")
        time.sleep(0.1)  # Adjust the sleep duration as needed


def ML_main():
    global running
    t1 = threading.Thread(target=sniffer)
    t1.daemon=True
    t1.start()

    # Specify your CSV file path
    csv_file_path = ('C:/Users/ccsit/Documents/RanSphere/RanSphere/NormalTraffic.csv')


    try:
        result = check_file_modification(csv_file_path)
        if (result):
            return result
        # Keep the script running indefinitely
        # while True:
        #     time.sleep(100)
    except KeyboardInterrupt:
        exit(0)

