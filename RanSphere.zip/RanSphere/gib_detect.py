#!/usr/bin/python
from scapy.all import *
from threading import Thread, Event
from time import sleep
from scapy.all import sniff
from scapy.layers.dns import DNSQR
import pickle
import gib_detect_train
import dbConnect

total_normal_count = 0
total_gib_count = 0

model_data = pickle.load(open('gib_model.pki', 'rb'))
checked_domains = set()

class Sniffer(Thread):
    def __init__(self, interface="Ethernet"):
        super().__init__()
        self.daemon = True
        self.socket = None
        self.interface = interface
        self.stop_sniffer = Event()

    def run(self):
        self.socket = conf.L2listen(type=ETH_P_ALL,iface=self.interface,)

        sniff(filter="(udp port 53) or (tcp port 53)",
            opened_socket=self.socket,prn=handle_packet,
            stop_filter=self.should_stop_sniffer,store=False
            )

    def join(self, timeout=None):
         self.stop_sniffer.set()
         super().join(timeout)

    def should_stop_sniffer(self, packet):
        return self.stop_sniffer.is_set()

def is_gibberish_domain(domain):
    """ Return False if the domain is gibberish """
    model_mat = model_data['mat']
    threshold = model_data['thresh']

    if gib_detect_train.avg_transition_prob(domain, model_mat) > threshold:
        return True
    else:
        return False


def handle_packet(packet):
    global total_normal_count
    global total_gib_count
    # Check if this is a DNS query
    if packet.haslayer(DNSQR):
        domain = packet[DNSQR].qname.decode("utf-8").rstrip('.')
        # Remove the 'www.' from the domain to avoid affecting the result
        if domain.startswith('www.'):
            domain = domain[4:]

        if domain in checked_domains:
            return
        else:
            checked_domains.add(domain)  # Remember this domain as checked
            domain_parts = domain.split('.')
            if is_gibberish_domain(domain_parts[0]):
                total_normal_count += 1  # Total normal domain count is used for the final print
            else:
                if len(domain_parts[0]) >= 8:
                    if '-' not in domain_parts[0]:
                        print(domain_parts[0])  # Extract Top and First level domain
                        total_gib_count+=1
                        dbConnect.addToDatabase(domain_parts[0])




def Gib_Main():
    global total_normal_count
    global gib_domain_count
    global total_gib_count

    print("*** Starting packet sniffing ***")
    sniffer = Sniffer()
    sniffer.start()
    try:
        while True:
            sleep(100)

    except KeyboardInterrupt:
        sniffer.stop_sniffer.set()
        print("*** Stop sniffing ***")
        sniffer.join(2.0)

        if sniffer.is_alive():
            sniffer.socket.close()

        print(f"* Number of 'Gibberish' domains encountered: {total_gib_count}")
        print(f"* Number of 'Normal' domains encountered: {total_normal_count}")

# if __name__ == "__main__":
#     Gib_Main()
# import csv
# import gib_detect_train
# import pickle
#
# total_normal_count = 0
# total_gib_count = 0
#
# model_data = pickle.load(open('gib_model.pki', 'rb'))
# checked_domains = set()
#
# def read_domains_from_csv(filename):
#     domains = []
#     with open(filename, 'r') as file:
#         reader = csv.reader(file)
#         for row in reader:
#             handle_domains_from_csv(row[0])
# def is_gibberish_domain(domain):
#     """ Return False if the domain is gibberish """
#     model_mat = model_data['mat']
#     threshold = model_data['thresh']
#
#     if gib_detect_train.avg_transition_prob(domain, model_mat) > threshold:
#         return True
#     else:
#         return False
#
# def handle_domains_from_csv(domain):
#     global total_normal_count
#     global total_gib_count
#
#     if domain in checked_domains:
#         return
#     else:
#         checked_domains.add(domain)  # Remember this domain as checked
#         domain_parts = domain.split('.')
#         if is_gibberish_domain(domain_parts[0]):
#             print(domain_parts[0])
#             total_normal_count += 1  # Total normal domain count is used for the final print
#         else:
#             if len(domain_parts[0]) >= 7 and '-' not in domain_parts[0]:
#                 # print(domain_parts[0])  # Extract Top and First level domain
#                 total_gib_count += 1
#
#
# def Gib_Main():
#     global total_normal_count
#     global total_gib_count
#
#     print("*** Reading domains from CSV file ***")
#     read_domains_from_csv('C:/Users/ccsit/Downloads/DGA_Domains (1).csv')
#     print(f"* Number of 'Gibberish' domains encountered: {total_gib_count}")
#     print(f"* Number of 'Normal' domains encountered: {total_normal_count}")
#
#
# if __name__ == "__main__":
#     Gib_Main()
