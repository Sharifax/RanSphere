import mysql.connector
from datetime import datetime

def addToDatabase(d):
    domain = d
    # Connect to the MySQL server
    db = mysql.connector.connect(
    host="localhost",
    user="RanSphereAdmin",
    password="12345678",
    database="ranspheredb"
    )

    # Create a cursor object
    cursor = db.cursor()

    # Prepare the SQL query
    sql = "INSERT INTO incidents (Attack, Date, Domains) VALUES (%s, %s, %s)"
    current_dateTime = datetime.now()
    values = ("Botnet Behavior", current_dateTime, domain)

    # Execute the query
    cursor.execute(sql, values)

    # Commit the changes
    db.commit()

    # Print the number of rows affected
    print(cursor.rowcount, "record inserted.")
